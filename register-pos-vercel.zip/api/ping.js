const { send, status, redis } = require('./_lib');

// Public health check used by the register's "QR order check". Reveals setup state only, no secrets.
module.exports = async (req, res) => {
  const { missing } = status();
  if (missing.length) return send(res, 503, { ok: false, missing });
  try {
    await redis('PING');
    const menu = (await redis('EXISTS', 'pos:menu')) === 1;
    return send(res, 200, { ok: true, missing: [], redis: 'ok', menu });
  } catch (e) {
    return send(res, 503, { ok: false, missing: [], redis: 'fail' });
  }
};
